package com.example.intelligence_engineering

import android.content.Intent
import androidx.activity.ComponentActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.intelligence_engineering.viewmodel.DataProjekData
import com.example.intelligence_engineering.viewmodel.ProjectViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class DataProjek : ComponentActivity() {
    private val projekViewModel: ProjectViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    ProjekInputScreen(projekViewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjekInputScreen(projekViewModel: ProjectViewModel = viewModel()) {
    val context = LocalContext.current

    var namaProjek by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, bottom = 10.dp)) {
            Text(
                text = "Input Data Proyek",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                fontSize = 25.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )
        }
        Box(modifier = Modifier
            .padding(start = 15.dp, end = 15.dp)
            .fillMaxHeight()) {
            Column(modifier = Modifier
                .background(Color(0xFFCFCFCF).copy(alpha = 0.6F))
                .fillMaxHeight()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                ) {
                    OutlinedTextField(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp),
                        value = namaProjek,
                        onValueChange = { namaProjek = it },
                        label = { Text("Nama Projek") },
                        colors = TextFieldDefaults.outlinedTextFieldColors(
                            containerColor = Color.White
                        )
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                        val dataProjek = DataProjekData(nama_projek = namaProjek)
                        saveDataProjekToFirestore(dataProjek) { id ->
                            val intent = Intent(context, MeanObj::class.java).apply {
                                putExtra("PROJEK_ID", id)
                            }
                            context.startActivity(intent)
                        }
                    },
                    modifier = Modifier
                        .padding(end = 10.dp)
                        .align(Alignment.CenterHorizontally)
                ) {
                    Text(text = "Save")
                }
                Spacer(modifier = Modifier.height(20.dp))
                Row(modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Button(
                        onClick = {
                            val intent = Intent(context, DisplayProjek::class.java)
                            context.startActivity(intent)
                        }
                    ) {
                        Text(text = "Go To Data Projek")
                    }
                }
            }
        }
    }
}

private fun saveDataProjekToFirestore(newEntry: DataProjekData, onSuccess: (String) -> Unit) {
    val db = FirebaseFirestore.getInstance()
    val docRef = db.collection("dataProjek").document()
    newEntry.meanObjId = docRef.id
    docRef.set(newEntry)
        .addOnSuccessListener {
            // Data berhasil disimpan
            Log.d("Firestore", "Data proyek berhasil disimpan dengan ID: ${docRef.id}")
            onSuccess(docRef.id)
        }
        .addOnFailureListener { e ->
            // Tangani kesalahan
            Log.e("Firestore", "Gagal menyimpan data proyek", e)
        }
}

@Preview(showBackground = true)
@Composable
fun ProjekInputScreenPreview() {
    ProjekInputScreen()
}
