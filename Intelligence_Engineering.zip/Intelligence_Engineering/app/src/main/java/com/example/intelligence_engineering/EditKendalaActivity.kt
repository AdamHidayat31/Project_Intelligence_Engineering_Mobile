package com.example.intelligence_engineering

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.intelligence_engineering.viewmodel.KendalaData
import com.example.intelligence_engineering.viewmodel.ProjectViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class EditKendalaActivity : ComponentActivity() {
    private val projectViewModel: ProjectViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        val projekId = intent.getStringExtra("PROJEK_ID") ?: ""
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    EditKendalaScreen(projectViewModel, projekId)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditKendalaScreen(projectViewModel: ProjectViewModel = viewModel(), projekId: String) {
    val context = LocalContext.current
    val db = FirebaseFirestore.getInstance()

    var kendalaList by remember { mutableStateOf<List<Pair<String, KendalaData>>>(emptyList()) }

    LaunchedEffect(projekId) {
        db.collection("dataProjek").document(projekId).collection("kendalaData").get().addOnSuccessListener { documents ->
            if (!documents.isEmpty) {
                val list = documents.map { document ->
                    document.id to document.toObject(KendalaData::class.java)
                }
                kendalaList = list
            }
        }
    }
    Column {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, bottom = 10.dp)
        ) {
            Text(
                text = "Edit Kendala Pengembangan",
                fontSize = 25.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(10.dp)
            )
        }
        Column (
            modifier = Modifier
                .padding(start = 15.dp, end = 15.dp)
                .fillMaxHeight()
        ){
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFCFCFCF).copy(alpha = 0.6F))
            ) {


                kendalaList.forEach { (id, data) ->
                    var masalahPengembangan by remember { mutableStateOf(data.masalahPengembangan) }

                    OutlinedTextField(
                        value = masalahPengembangan,
                        onValueChange = { masalahPengembangan = it },
                        label = { Text("Masalah Pengembangan") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp),
                        colors = TextFieldDefaults.outlinedTextFieldColors(
                            containerColor = Color.White
                        )
                    )

                    Button(
                        onClick = {
                            val updatedData = KendalaData(
                                masalahPengembangan = masalahPengembangan
                            )
                            db.collection("dataProjek").document(projekId).collection("kendalaData").document(id).set(updatedData)
                                .addOnSuccessListener {
                                    val intent = Intent(context, DisplayActivity::class.java).apply {
                                        putExtra("PROJEK_ID", projekId)
                                    }
                                    context.startActivity(intent)
                                }
                                .addOnFailureListener {
                                    // Handle failure
                                }
                        },
                        modifier = Modifier
                            .padding(top = 2.dp, bottom = 5.dp)
                            .align(Alignment.CenterHorizontally)
                    ) {
                        Text("Save")
                    }
                }
            }
        }
    }

}

@Preview(showBackground = true)
@Composable
fun EditKendalaScreenPreview() {
    EditKendalaScreen(projekId = "dummy_projek_id")
}
