package com.example.intelligence_engineering

import android.content.Intent
import androidx.activity.ComponentActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.intelligence_engineering.viewmodel.KendalaData
import com.example.intelligence_engineering.viewmodel.StatusData
import com.example.intelligence_engineering.viewmodel.ProjectViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class KendalaStatus : ComponentActivity() {
    private val projectViewModel: ProjectViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        val projekId = intent.getStringExtra("PROJEK_ID") ?: ""
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    KendaladanStatus(projectViewModel, projekId)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KendaladanStatus(projectViewModel: ProjectViewModel = viewModel(), projekId: String) {
    val context = LocalContext.current

    var masalahPengembangan by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, bottom = 10.dp)
        ) {
            Text(
                text = "Kendala dan Status Sistem",
                fontSize = 25.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(10.dp)
            )
        }
        Box(
            modifier = Modifier
                .padding(start = 15.dp, end = 15.dp)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .background(Color(0xFFCFCFCF).copy(alpha = 0.6F))
                    .fillMaxHeight()
            ) {
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .fillMaxWidth(),
                    value = masalahPengembangan,
                    onValueChange = { masalahPengembangan = it },
                    label = { Text("Kendala Pengembangan") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                Row(Modifier.padding(top = 5.dp)) {
                    Spacer(modifier = Modifier.weight(1f))
                    Button(
                        onClick = {
                            val kendalaData = KendalaData(masalahPengembangan)
                            projectViewModel.saveKendalaData(kendalaData)
                            saveKendalaToFirestore(kendalaData, projekId)
                        },
                        modifier = Modifier
                            .width(135.dp)
                            .padding(end = 3.dp)
                    ) {
                        Text(text = "Save Kendala")
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .fillMaxWidth(),
                    value = status,
                    onValueChange = { status = it },
                    label = { Text("Status yang Terealisasi") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                Row(Modifier.padding(top = 5.dp)) {
                    Spacer(modifier = Modifier.weight(1f))
                    Button(
                        onClick = {
                            val statusData = StatusData(status)
                            projectViewModel.saveStatusData(statusData)
                            saveStatusToFirestore(statusData, projekId)
                        },
                        modifier = Modifier
                            .width(135.dp)
                            .padding(end = 3.dp)
                    ) {
                        Text(text = "Save Status")
                    }
                }
                Spacer(modifier = Modifier.height(50.dp))
                Row(modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Button(
                        onClick = {
                            val intent = Intent(context, PerImp::class.java).apply {
                                putExtra("PROJEK_ID", projekId)
                            }
                            context.startActivity(intent)
                        }
                    ) {
                        Text(text = "Input Perencanaan Impelementasi")
                    }
                }
            }
        }
    }
}

private fun saveKendalaToFirestore(newEntry: KendalaData, projekId: String) {
    val db = FirebaseFirestore.getInstance()
    db.collection("dataProjek").document(projekId)
        .collection("kendalaData")
        .add(newEntry)
        .addOnSuccessListener {
            // Data berhasil disimpan
            Log.d("Firestore", "Data kendala berhasil disimpan")
        }
        .addOnFailureListener { e ->
            // Tangani kesalahan
            Log.e("Firestore", "Gagal menyimpan data kendala", e)
        }
}

private fun saveStatusToFirestore(newEntry: StatusData, projekId: String) {
    val db = FirebaseFirestore.getInstance()
    db.collection("dataProjek").document(projekId)
        .collection("statusData")
        .add(newEntry)
        .addOnSuccessListener {
            // Data berhasil disimpan
            Log.d("Firestore", "Data status berhasil disimpan")
        }
        .addOnFailureListener { e ->
            // Tangani kesalahan
            Log.e("Firestore", "Gagal menyimpan data status", e)
        }
}

@Preview(showBackground = true)
@Composable
fun KendaladanStatusPreview() {
    KendaladanStatus(projekId = "dummy_projek_id")
}
