package com.example.intelligence_engineering

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.intelligence_engineering.viewmodel.*
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class DisplayActivity : ComponentActivity() {
    private val projectViewModel: ProjectViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        val projekId = intent.getStringExtra("PROJEK_ID") ?: ""
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    DisplayDataScreen(projectViewModel, projekId)
                }
            }
        }
    }
}

@Composable
fun DisplayDataScreen(projectViewModel: ProjectViewModel = viewModel(), projekId: String) {
    val context = LocalContext.current
    val db = FirebaseFirestore.getInstance()

    var dataProjek by remember { mutableStateOf<DataProjekData?>(null) }
    var meanObjData by remember { mutableStateOf<MeanObjData?>(null) }
    var intExpData by remember { mutableStateOf<IntExpData?>(null) }
    var intImpData by remember { mutableStateOf<IntImpData?>(null) }
    var kendalaList by remember { mutableStateOf<List<KendalaData>>(emptyList()) }
    var statusList by remember { mutableStateOf<List<StatusData>>(emptyList()) }
    var perImpData by remember { mutableStateOf<PerImpData?>(null) }

    LaunchedEffect(projekId) {
        Log.d("Firestore", "Fetching data for projekId: $projekId")

        db.collection("dataProjek").document(projekId).get().addOnSuccessListener { document ->
            dataProjek = document.toObject(DataProjekData::class.java)
            Log.d("Firestore", "DataProjek: $dataProjek")
        }.addOnFailureListener { e ->
            Log.e("Firestore", "Failed to fetch DataProjek", e)
        }

        db.collection("dataProjek").document(projekId).collection("meanObjData").get().addOnSuccessListener { documents ->
            if (!documents.isEmpty) {
                meanObjData = documents.documents[0].toObject(MeanObjData::class.java)
                Log.d("Firestore", "MeanObjData: $meanObjData")
            }
        }.addOnFailureListener { e ->
            Log.e("Firestore", "Failed to fetch MeanObjData", e)
        }

        db.collection("dataProjek").document(projekId).collection("intExpData").get().addOnSuccessListener { documents ->
            if (!documents.isEmpty) {
                intExpData = documents.documents[0].toObject(IntExpData::class.java)
                Log.d("Firestore", "IntExpData: $intExpData")
            }
        }.addOnFailureListener { e ->
            Log.e("Firestore", "Failed to fetch IntExpData", e)
        }

        db.collection("dataProjek").document(projekId).collection("intImpData").get().addOnSuccessListener { documents ->
            if (!documents.isEmpty) {
                intImpData = documents.documents[0].toObject(IntImpData::class.java)
                Log.d("Firestore", "IntImpData: $intImpData")
            }
        }.addOnFailureListener { e ->
            Log.e("Firestore", "Failed to fetch IntImpData", e)
        }

        db.collection("dataProjek").document(projekId).collection("kendalaData").get().addOnSuccessListener { documents ->
            kendalaList = documents.mapNotNull { it.toObject(KendalaData::class.java) }
            Log.d("Firestore", "KendalaList: $kendalaList")
        }.addOnFailureListener { e ->
            Log.e("Firestore", "Failed to fetch KendalaData", e)
        }

        db.collection("dataProjek").document(projekId).collection("statusData").get().addOnSuccessListener { documents ->
            statusList = documents.mapNotNull { it.toObject(StatusData::class.java) }
            Log.d("Firestore", "StatusList: $statusList")
        }.addOnFailureListener { e ->
            Log.e("Firestore", "Failed to fetch StatusData", e)
        }

        db.collection("dataProjek").document(projekId).collection("perImpData").get().addOnSuccessListener { documents ->
            if (!documents.isEmpty) {
                perImpData = documents.documents[0].toObject(PerImpData::class.java)
                Log.d("Firestore", "PerImpData: $perImpData")
            }
        }.addOnFailureListener { e ->
            Log.e("Firestore", "Failed to fetch PerImpData", e)
        }
    }

    Column(
        modifier = Modifier
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Project Data", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Column (
            Modifier
                .background(Color(0xFFE7E0EC))
                .fillMaxWidth()){
            dataProjek?.let {
                Text("Nama Projek: ${it.nama_projek}")
            }
        }
        

        Spacer(modifier = Modifier.height(16.dp))
        Text("Meaningful Objective", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Column (
            Modifier
                .background(Color(0xFFE7E0EC))
                .fillMaxWidth()){
            meanObjData?.let {

                Text("Organization Objective: ${it.organizationObjective}")
                Text("Leading Indicator: ${it.leadingIndicator}")
                Text("User Outcomes: ${it.userOutcomes}")
                Text("Model Properties:m ${it.modelProperties}")
            }
            Row {
                Spacer(modifier = Modifier.weight(1F))
                Button(onClick = {
                    val intent = Intent(context, EditMeanObjActivity::class.java).apply {
                        putExtra("PROJEK_ID", projekId)
                    }
                    context.startActivity(intent)
                }) {
                    Text("Edit")
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        Text("Intelligence Experience", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Column (
            Modifier
                .background(Color(0xFFE7E0EC))
                .fillMaxWidth()){
            intExpData?.let {
                Text(text = "Presenting Intelligence to User")
                Text("   Automate: ${it.automate}")
                Text("   Prompt: ${it.prompt}")
                Text("   Organization: ${it.organization}")
                Text("   Annotate: ${it.annotate}")
                Text("Achieve System: ${it.achieveSystem}")
                Text("Minimize Flaws: ${it.minimizeFlaws}")
                Text("Data Grown System: ${it.dataGrownSystem}")
            }
            Row {
                Spacer(modifier = Modifier.weight(1F))
                Button(onClick = {
                    val intent = Intent(context, EditIntExpActivity::class.java).apply {
                        putExtra("PROJEK_ID", projekId)
                    }
                    context.startActivity(intent)
                }) {
                    Text("Edit")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Intelligence Implementation", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Column (
            Modifier
                .background(Color(0xFFE7E0EC))
                .fillMaxWidth()){
            intImpData?.let {
                Text("Proses Bisnis: ${it.proses_bisnis}")
                Text("Teknologi Dipakai: ${it.teknologi_dipakai}")
                Text("Sistem Cerdas: ${it.sistem_cerdas}")
            }
            Row {
                Spacer(modifier = Modifier.weight(1F))
                Button(onClick = {
                    val intent = Intent(context, EditIntImpActivity::class.java).apply {
                        putExtra("PROJEK_ID", projekId)
                    }
                    context.startActivity(intent)
                }) {
                    Text("Edit")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Kendala Pengembangan", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Column(
            Modifier
                .background(Color(0xFFE7E0EC))
                .fillMaxWidth()) {
            kendalaList.forEach { kendala ->
                Text("${kendala.masalahPengembangan}")
            }
            Row {
                Spacer(modifier = Modifier.weight(1F))
                Button(onClick = {
                    val intent = Intent(context, AddKendalaActivity::class.java).apply {
                        putExtra("PROJEK_ID", projekId)
                    }
                    context.startActivity(intent)
                }) {
                    Text("Add")
                }
                Button(onClick = {
                    val intent = Intent(context, EditKendalaActivity::class.java).apply {
                        putExtra("PROJEK_ID", projekId)
                    }
                    context.startActivity(intent)
                }) {
                    Text("Edit")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Status Realisasi", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Column (
            Modifier
                .background(Color(0xFFE7E0EC))
                .fillMaxWidth()) {
            statusList.forEach { status ->
                Text("${status.status}")
            }
            Row {
                Spacer(modifier = Modifier.weight(1F))
                Button(onClick = {
                    val intent = Intent(context, AddStatusActivity::class.java).apply {
                        putExtra("PROJEK_ID", projekId)
                    }
                    context.startActivity(intent)
                }) {
                    Text("Add")
                }
                Button(onClick = {
                    val intent = Intent(context, EditStatusActivity::class.java).apply {
                        putExtra("PROJEK_ID", projekId)
                    }
                    context.startActivity(intent)
                }) {
                    Text("Edit")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Perencanaan Implementasi", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Column(
            Modifier
                .background(Color(0xFFE7E0EC))
                .fillMaxWidth()) {
            perImpData?.let {
                Text("Pelaksanaan Deployment: ${it.pelaksanaanDeployment}")
                Text("Pemeliharaan Sistem: ${it.pemeliharaanSistem}")
                Text("Pelaksanaan Operasi: ${it.pelaksanaanOperasi}")
            }
            Row {
                Spacer(modifier = Modifier.weight(1F))
                Button(onClick = {
                    val intent = Intent(context, EditPerImpActivity::class.java).apply {
                        putExtra("PROJEK_ID", projekId)
                    }
                    context.startActivity(intent)
                }) {
                    Text("Edit")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                val intent = Intent(context, DisplayProjek::class.java)
                context.startActivity(intent)
            },
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text(text = "Go to Data Projek")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DisplayDataScreenPreview() {
    DisplayDataScreen(projekId = "dummy_projek_id")
}
