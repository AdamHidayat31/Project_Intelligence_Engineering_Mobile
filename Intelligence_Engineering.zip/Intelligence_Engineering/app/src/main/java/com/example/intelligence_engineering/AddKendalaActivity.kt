package com.example.intelligence_engineering

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.intelligence_engineering.viewmodel.KendalaData
import com.example.intelligence_engineering.viewmodel.ProjectViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class AddKendalaActivity : ComponentActivity() {
    private val projectViewModel: ProjectViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        val projekId = intent.getStringExtra("PROJEK_ID") ?: ""
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    AddKendalaScreen(projectViewModel, projekId)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddKendalaScreen(projectViewModel: ProjectViewModel = viewModel(), projekId: String) {
    val context = LocalContext.current
    var masalahPengembangan by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFCFCFCF).copy(alpha = 0.6F))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, bottom = 10.dp)
        ) {
            Text(
                text = "Add Kendala Pengembangan",
                fontSize = 25.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(10.dp)
            )
        }

        OutlinedTextField(
            value = masalahPengembangan,
            onValueChange = { masalahPengembangan = it },
            label = { Text("Masalah Pengembangan") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                containerColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                val newKendala = KendalaData(
                    masalahPengembangan = masalahPengembangan
                )
                saveKendalaToFirestore(newKendala, projekId) {
                    val intent = Intent(context, DisplayActivity::class.java).apply {
                        putExtra("PROJEK_ID", projekId)
                    }
                    context.startActivity(intent)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .align(Alignment.CenterHorizontally)
        ) {
            Text("Save")
        }
    }
}

private fun saveKendalaToFirestore(newEntry: KendalaData, projekId: String, onSuccess: () -> Unit) {
    val db = FirebaseFirestore.getInstance()
    db.collection("dataProjek").document(projekId)
        .collection("kendalaData")
        .add(newEntry)
        .addOnSuccessListener {
            onSuccess()
        }
        .addOnFailureListener { e ->
            // Handle failure
        }
}

@Preview(showBackground = true)
@Composable
fun AddKendalaScreenPreview() {
    AddKendalaScreen(projekId = "dummy_projek_id")
}
