package com.example.intelligence_engineering

import android.content.Intent
import androidx.activity.ComponentActivity
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.intelligence_engineering.viewmodel.DataProjekData
import com.example.intelligence_engineering.viewmodel.ProjectViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class DisplayProjek : ComponentActivity() {
    private val projectViewModel: ProjectViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    DisplayProjekScreen(projectViewModel)
                }
            }
        }
    }
}

@Composable
fun DisplayProjekScreen(projectViewModel: ProjectViewModel = viewModel()) {
    val context = LocalContext.current
    val db = FirebaseFirestore.getInstance()

    var dataProjekList by remember { mutableStateOf<List<DataProjekData>>(emptyList()) }

    LaunchedEffect(Unit) {
        db.collection("dataProjek").get().addOnSuccessListener { documents ->
            val projekList = documents.mapNotNull { it.toObject(DataProjekData::class.java).apply { meanObjId = it.id } }
            dataProjekList = projekList
        }
    }

    Column(
        modifier = Modifier
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row {
            Text("Daftar Proyek", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }


        Spacer(modifier = Modifier.height(16.dp))

        for (projek in dataProjekList) {
            Card(modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)) {
                Row(modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(projek.nama_projek, fontSize = 18.sp)
                    Button(onClick = {
                        val intent = Intent(context, DisplayActivity::class.java).apply {
                            putExtra("PROJEK_ID", projek.meanObjId)
                        }
                        context.startActivity(intent)
                    }) {
                        Text("Lihat")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val intent = Intent(context, DataProjek::class.java)
                context.startActivity(intent)
            },
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text(text = "Go To Input DataProjek")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DisplayProjekScreenPreview() {
    DisplayProjekScreen()
}
