package com.example.intelligence_engineering

import android.content.Intent
import androidx.activity.ComponentActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.intelligence_engineering.viewmodel.IntImpData
import com.example.intelligence_engineering.viewmodel.ProjectViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class IntImp : ComponentActivity() {
    private val projectViewModel: ProjectViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        val projekId = intent.getStringExtra("PROJEK_ID") ?: ""
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    IntelligenceImplementation(projectViewModel, projekId)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IntelligenceImplementation(projectViewModel: ProjectViewModel = viewModel(), projekId: String) {
    val context = LocalContext.current

    var prosesBisnis by remember { mutableStateOf("") }
    var teknologiDipakai by remember { mutableStateOf("") }
    var sistemCerdas by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, bottom = 10.dp)
        ) {
            Text(
                text = "Intelligence Implementation",
                fontSize = 25.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(10.dp)
            )
        }
        Box(
            modifier = Modifier
                .padding(start = 15.dp, end = 15.dp)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .background(Color(0xFFCFCFCF).copy(alpha = 0.6F))
                    .fillMaxHeight()
            ) {
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .fillMaxWidth(),
                    value = prosesBisnis,
                    onValueChange = { prosesBisnis = it },
                    label = { Text("Proses Bisnis Sistem Cerdas") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .fillMaxWidth(),
                    value = teknologiDipakai,
                    onValueChange = { teknologiDipakai = it },
                    label = { Text("Teknologi Yang Akan di Pakai") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .fillMaxWidth(),
                    value = sistemCerdas,
                    onValueChange = { sistemCerdas = it },
                    label = { Text("Proses Yang Menjadi Cerdas") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                        val intImpData = IntImpData(
                            prosesBisnis,
                            teknologiDipakai,
                            sistemCerdas
                        )
                        projectViewModel.saveIntImpData(intImpData)
                        saveIntImpToFirestore(intImpData, projekId) {
                            val intent = Intent(context, KendalaStatus::class.java).apply {
                                putExtra("PROJEK_ID", projekId)
                            }
                            context.startActivity(intent)
                        }
                    },
                    modifier = Modifier
                        .width(135.dp)
                        .align(Alignment.CenterHorizontally)
                ) {
                    Text(text = "Save")
                }
            }
        }
    }
}

private fun saveIntImpToFirestore(newEntry: IntImpData, projekId: String, onSuccess: () -> Unit) {
    val db = FirebaseFirestore.getInstance()
    db.collection("dataProjek").document(projekId)
        .collection("intImpData")
        .add(newEntry)
        .addOnSuccessListener {
            // Data berhasil disimpan
            Log.d("Firestore", "Data berhasil disimpan")
            onSuccess()
        }
        .addOnFailureListener { e ->
            // Tangani kesalahan
            Log.e("Firestore", "Gagal menyimpan data", e)
        }
}

@Preview(showBackground = true)
@Composable
fun IntelligenceImplementationPreview() {
    IntelligenceImplementation(projekId = "dummy_projek_id")
}
