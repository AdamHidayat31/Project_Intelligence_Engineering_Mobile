package com.example.intelligence_engineering.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class ProjectViewModel : ViewModel() {
    private val db = FirebaseFirestore.getInstance()

    // LiveData untuk setiap data class
    private val _dataProjek = MutableLiveData<DataProjekData>()
    val dataProjek: LiveData<DataProjekData> get() = _dataProjek

    private val _meanObjData = MutableLiveData<MeanObjData>()
    val meanObjData: LiveData<MeanObjData> get() = _meanObjData

    private val _intExpData = MutableLiveData<IntExpData>()
    val intExpData: LiveData<IntExpData> get() = _intExpData

    private val _intImpData = MutableLiveData<IntImpData>()
    val intImpData: LiveData<IntImpData> get() = _intImpData

    private val _kendalaData = MutableLiveData<KendalaData>()
    val kendalaData: LiveData<KendalaData> get() = _kendalaData

    private val _statusData = MutableLiveData<StatusData>()
    val statusData: LiveData<StatusData> get() = _statusData

    private val _perImpData = MutableLiveData<PerImpData>()
    val perImpData: LiveData<PerImpData> get() = _perImpData

    // Fungsi untuk menyimpan DataProjekData
    fun saveDataProjek(dataProjek: DataProjekData) {
        val docRef = db.collection("dataProjek").document()
        dataProjek.meanObjId = docRef.id
        docRef.set(dataProjek)
            .addOnSuccessListener {
                _dataProjek.value = dataProjek
            }
            .addOnFailureListener { e ->
                // Handle failure
            }
    }

    // Fungsi untuk menyimpan MeanObjData
    fun saveMeanObjData(meanObjData: MeanObjData) {
        val projekId = _dataProjek.value?.meanObjId ?: return
        db.collection("dataProjek").document(projekId)
            .collection("meanObjData").document()
            .set(meanObjData)
            .addOnSuccessListener {
                _meanObjData.value = meanObjData
            }
            .addOnFailureListener { e ->
                // Handle failure
            }
    }

    // Fungsi untuk menyimpan IntExpData
    fun saveIntExpData(intExpData: IntExpData) {
        val projekId = _dataProjek.value?.meanObjId ?: return
        db.collection("dataProjek").document(projekId)
            .collection("intExpData").document()
            .set(intExpData)
            .addOnSuccessListener {
                _intExpData.value = intExpData
            }
            .addOnFailureListener { e ->
                // Handle failure
            }
    }

    // Fungsi untuk menyimpan IntImpData
    fun saveIntImpData(intImpData: IntImpData) {
        val projekId = _dataProjek.value?.meanObjId ?: return
        db.collection("dataProjek").document(projekId)
            .collection("intImpData").document()
            .set(intImpData)
            .addOnSuccessListener {
                _intImpData.value = intImpData
            }
            .addOnFailureListener { e ->
                // Handle failure
            }
    }

    // Fungsi untuk menyimpan KendalaData
    fun saveKendalaData(kendalaData: KendalaData) {
        val projekId = _dataProjek.value?.meanObjId ?: return
        db.collection("dataProjek").document(projekId)
            .collection("kendalaData").document()
            .set(kendalaData)
            .addOnSuccessListener {
                _kendalaData.value = kendalaData
            }
            .addOnFailureListener { e ->
                // Handle failure
            }
    }

    // Fungsi untuk menyimpan StatusData
    fun saveStatusData(statusData: StatusData) {
        val projekId = _dataProjek.value?.meanObjId ?: return
        db.collection("dataProjek").document(projekId)
            .collection("statusData").document()
            .set(statusData)
            .addOnSuccessListener {
                _statusData.value = statusData
            }
            .addOnFailureListener { e ->
                // Handle failure
            }
    }

    // Fungsi untuk menyimpan PerImpData
    fun savePerImpData(perImpData: PerImpData) {
        val projekId = _dataProjek.value?.meanObjId ?: return
        db.collection("dataProjek").document(projekId)
            .collection("perImpData").document()
            .set(perImpData)
            .addOnSuccessListener {
                _perImpData.value = perImpData
            }
            .addOnFailureListener { e ->
                // Handle failure
            }
    }
}

data class DataProjekData(
    val nama_projek: String = "",
    var meanObjId: String = "" // Tambahkan field untuk menyimpan ID MeanObj
) {
    constructor() : this("", "")
}

data class MeanObjData(
    val organizationObjective: String = "",
    val leadingIndicator: String = "",
    val userOutcomes: String = "",
    val modelProperties: String = ""
) {
    constructor() : this("", "", "", "")
}

data class IntExpData(
    val automate: String = "",
    val prompt: String = "",
    val organization: String = "",
    val annotate: String = "",
    val achieveSystem: String = "",
    val minimizeFlaws: String = "",
    val dataGrownSystem: String = ""
) {
    constructor() : this("", "", "", "", "", "", "")
}

data class IntImpData(
    val proses_bisnis: String = "",
    val teknologi_dipakai: String = "",
    val sistem_cerdas: String = ""
) {
    constructor() : this("", "", "")
}

data class KendalaData(
    val masalahPengembangan: String = ""
) {
    constructor() : this("")
}

data class StatusData(
    val status: String = ""
) {
    constructor() : this("")
}

data class PerImpData(
    val pelaksanaanDeployment: String = "",
    val pemeliharaanSistem: String = "",
    val pelaksanaanOperasi: String = ""
) {
    constructor() : this("", "", "")
}
