package com.example.intelligence_engineering

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.intelligence_engineering.viewmodel.PerImpData
import com.example.intelligence_engineering.viewmodel.ProjectViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class EditPerImpActivity : ComponentActivity() {
    private val projectViewModel: ProjectViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        val projekId = intent.getStringExtra("PROJEK_ID") ?: ""
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    EditPerImpScreen(projectViewModel, projekId)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditPerImpScreen(projectViewModel: ProjectViewModel = viewModel(), projekId: String) {
    val context = LocalContext.current
    val db = FirebaseFirestore.getInstance()

    var perImpData by remember { mutableStateOf<PerImpData?>(null) }
    var docId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(projekId) {
        db.collection("dataProjek").document(projekId).collection("perImpData").get().addOnSuccessListener { documents ->
            if (!documents.isEmpty) {
                val document = documents.documents[0]
                perImpData = document.toObject(PerImpData::class.java)
                docId = document.id
            }
        }
    }

    perImpData?.let { data ->
        var pelaksanaanDeployment by remember { mutableStateOf(data.pelaksanaanDeployment) }
        var pemeliharaanSistem by remember { mutableStateOf(data.pemeliharaanSistem) }
        var pelaksanaanOperasi by remember { mutableStateOf(data.pelaksanaanOperasi) }

        Column(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp, bottom = 10.dp)
            ) {
                Text(
                    text = "Edit Perencanaan Implementasi",
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(10.dp)
                )
            }
            Box(
                modifier = Modifier
                    .padding(start = 15.dp, end = 15.dp)
                    .fillMaxHeight()
            ) {
                Column(
                    modifier = Modifier
                        .background(Color(0xFFCFCFCF).copy(alpha = 0.6F))
                        .fillMaxHeight()
                ) {
                    OutlinedTextField(
                        modifier = Modifier
                            .padding(horizontal = 8.dp)
                            .fillMaxWidth(),
                        value = pelaksanaanDeployment,
                        onValueChange = { pelaksanaanDeployment = it },
                        label = { Text("Penetapan Pelaksanaan Deployment") },
                        colors = TextFieldDefaults.outlinedTextFieldColors(
                            containerColor = Color.White
                        )
                    )
                    OutlinedTextField(
                        modifier = Modifier
                            .padding(horizontal = 8.dp)
                            .fillMaxWidth(),
                        value = pemeliharaanSistem,
                        onValueChange = { pemeliharaanSistem = it },
                        label = { Text("Pemeliharaan Sistem Cerdas") },
                        colors = TextFieldDefaults.outlinedTextFieldColors(
                            containerColor = Color.White
                        )
                    )
                    OutlinedTextField(
                        modifier = Modifier
                            .padding(horizontal = 8.dp)
                            .fillMaxWidth(),
                        value = pelaksanaanOperasi,
                        onValueChange = { pelaksanaanOperasi = it },
                        label = { Text("Pelaksanaan Operasi Sistem Cerdas") },
                        colors = TextFieldDefaults.outlinedTextFieldColors(
                            containerColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = {
                            val updatedData = PerImpData(
                                pelaksanaanDeployment = pelaksanaanDeployment,
                                pemeliharaanSistem = pemeliharaanSistem,
                                pelaksanaanOperasi = pelaksanaanOperasi
                            )
                            docId?.let { id ->
                                db.collection("dataProjek").document(projekId).collection("perImpData").document(id).set(updatedData)
                                    .addOnSuccessListener {
                                        val intent = Intent(context, DisplayActivity::class.java).apply {
                                            putExtra("PROJEK_ID", projekId)
                                        }
                                        context.startActivity(intent)
                                    }
                                    .addOnFailureListener {
                                        // Handle failure
                                    }
                            }
                        },
                        modifier = Modifier
                            .width(135.dp)
                            .align(Alignment.CenterHorizontally)
                    ) {
                        Text(text = "Save")
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun EditPerImpScreenPreview() {
    EditPerImpScreen(projekId = "dummy_projek_id")
}
