package com.example.intelligence_engineering

import android.content.Context
import android.content.Intent
import androidx.activity.ComponentActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.intelligence_engineering.viewmodel.IntExpData
import com.example.intelligence_engineering.viewmodel.ProjectViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class IntExp : ComponentActivity() {
    private val projectViewModel: ProjectViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        val projekId = intent.getStringExtra("PROJEK_ID") ?: ""
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    IntelligenceExperience(projectViewModel, projekId)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IntelligenceExperience(projectViewModel: ProjectViewModel = viewModel(), projekId: String) {
    val context = LocalContext.current

    var automate by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var organization by remember { mutableStateOf("") }
    var annotate by remember { mutableStateOf("") }
    var achieveSystem by remember { mutableStateOf("") }
    var minimizeFlaws by remember { mutableStateOf("") }
    var dataGrownSystem by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, bottom = 10.dp)
        ) {
            Text(
                text = "Intelligence Experience",
                fontSize = 25.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(10.dp)
            )
        }
        Box(
            modifier = Modifier
                .padding(start = 15.dp, end = 15.dp)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .background(Color(0xFFCFCFCF).copy(alpha = 0.6F))
                    .fillMaxHeight()
            ) {
                Text(text = "Presenting Intelligence To User", Modifier.padding(start = 8.dp))
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .padding(start = 10.dp)
                        .fillMaxWidth(),
                    value = automate,
                    onValueChange = { automate = it },
                    label = { Text("Automate") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .padding(start = 10.dp)
                        .fillMaxWidth(),
                    value = prompt,
                    onValueChange = { prompt = it },
                    label = { Text("Prompt") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .padding(start = 10.dp)
                        .fillMaxWidth(),
                    value = organization,
                    onValueChange = { organization = it },
                    label = { Text("Organization") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .padding(start = 10.dp)
                        .fillMaxWidth(),
                    value = annotate,
                    onValueChange = { annotate = it },
                    label = { Text("Annotate") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .fillMaxWidth(),
                    value = achieveSystem,
                    onValueChange = { achieveSystem = it },
                    label = { Text("Achieve System Objective") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .fillMaxWidth(),
                    value = minimizeFlaws,
                    onValueChange = { minimizeFlaws = it },
                    label = { Text("Minimize Intelligence Flaws") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .fillMaxWidth(),
                    value = dataGrownSystem,
                    onValueChange = { dataGrownSystem = it },
                    label = { Text("Create Data to Grown System") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                        val intExpData = IntExpData(
                            automate,
                            prompt,
                            organization,
                            annotate,
                            achieveSystem,
                            minimizeFlaws,
                            dataGrownSystem
                        )
                        projectViewModel.saveIntExpData(intExpData)
                        saveIntExpToFirestore(intExpData, projekId)
                    },
                    modifier = Modifier
                        .width(135.dp)
                        .align(Alignment.CenterHorizontally)
                ) {
                    Text(text = "Save")
                }
                Spacer(modifier = Modifier.height(50.dp))
                Row(modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Button(
                        onClick = {
                            val intent = Intent(context, DisplayActivity::class.java)
                            context.startActivity(intent)
                        }
                    ) {
                        Text(text = "Lihat Data Tersimpan")
                    }
                    Button(
                        onClick = {
                            val intent = Intent(context, IntImp::class.java).apply {
                                putExtra("PROJEK_ID", projekId)
                            }
                            context.startActivity(intent)
                        }
                    ) {
                        Text(text = "Next")
                    }
                }
            }
        }
    }
}

private fun saveIntExpToFirestore(newEntry: IntExpData, projekId: String) {
    val db = FirebaseFirestore.getInstance()
    db.collection("dataProjek").document(projekId)
        .collection("intExpData")
        .add(newEntry)
        .addOnSuccessListener {
            // Data berhasil disimpan
            Log.d("Firestore", "Data berhasil disimpan")
        }
        .addOnFailureListener { e ->
            // Tangani kesalahan
            Log.e("Firestore", "Gagal menyimpan data", e)
        }
}

@Preview(showBackground = true)
@Composable
fun IntelligenceExperiencePreview() {
    IntelligenceExperience(projekId = "dummy_projek_id")
}
