package com.example.intelligence_engineering

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.intelligence_engineering.viewmodel.StatusData
import com.example.intelligence_engineering.viewmodel.ProjectViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class EditStatusActivity : ComponentActivity() {
    private val projectViewModel: ProjectViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        val projekId = intent.getStringExtra("PROJEK_ID") ?: ""
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    EditStatusScreen(projectViewModel, projekId)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditStatusScreen(projectViewModel: ProjectViewModel = viewModel(), projekId: String) {
    val context = LocalContext.current
    val db = FirebaseFirestore.getInstance()

    var statusList by remember { mutableStateOf<List<Pair<String, StatusData>>>(emptyList()) }

    LaunchedEffect(projekId) {
        db.collection("dataProjek").document(projekId).collection("statusData").get().addOnSuccessListener { documents ->
            if (!documents.isEmpty) {
                val list = documents.map { document ->
                    document.id to document.toObject(StatusData::class.java)
                }
                statusList = list
            }
        }
    }

    Column {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, bottom = 10.dp)
        ) {
            Text(
                text = "Edit Status Realisasi",
                fontSize = 25.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(10.dp)
            )
        }
        Column(
            modifier = Modifier
                .padding(start = 15.dp, end = 15.dp)
                .fillMaxHeight()
        ) {
            Column (
                modifier = Modifier
                    .background(Color(0xFFCFCFCF).copy(alpha = 0.6F))
                    .fillMaxHeight()
            ) {
                statusList.forEach { (id, data) ->
                    var status by remember { mutableStateOf(data.status) }

                    OutlinedTextField(
                        value = status,
                        onValueChange = { status = it },
                        label = { Text("Status") },
                        colors = TextFieldDefaults.outlinedTextFieldColors(
                            containerColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp)
                    )

                    Button(
                        onClick = {
                            val updatedData = StatusData(
                                status = status
                            )
                            db.collection("dataProjek").document(projekId).collection("statusData").document(id).set(updatedData)
                                .addOnSuccessListener {
                                    val intent = Intent(context, DisplayActivity::class.java).apply {
                                        putExtra("PROJEK_ID", projekId)
                                    }
                                    context.startActivity(intent)
                                }
                                .addOnFailureListener {
                                    // Handle failure
                                }
                        },
                        modifier = Modifier
                            .padding(top = 2.dp, bottom = 5.dp)
                            .align(Alignment.CenterHorizontally)
                    ) {
                        Text("Save")
                    }

                }
            }


        }
    }

}

@Preview(showBackground = true)
@Composable
fun EditStatusScreenPreview() {
    EditStatusScreen(projekId = "dummy_projek_id")
}
