package com.example.intelligence_engineering

import android.content.Context
import android.content.Intent
import androidx.activity.ComponentActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.intelligence_engineering.viewmodel.MeanObjData
import com.example.intelligence_engineering.viewmodel.ProjectViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class MeanObj : ComponentActivity() {
    private val projectViewModel: ProjectViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        val projekId = intent.getStringExtra("PROJEK_ID") ?: ""
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    MeanObjInputScreen(projectViewModel, projekId)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MeanObjInputScreen(projectViewModel: ProjectViewModel = viewModel(), projekId: String) {
    val context = LocalContext.current

    var organizationObjective by remember { mutableStateOf("") }
    var leadingIndicator by remember { mutableStateOf("") }
    var userOutcomes by remember { mutableStateOf("") }
    var modelProperties by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, bottom = 10.dp)
        ) {
            Text(
                text = "Meaningful Objective",
                fontSize = 25.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(10.dp)
            )
        }
        Box(
            modifier = Modifier
                .padding(start = 15.dp, end = 15.dp)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .background(Color(0xFFCFCFCF).copy(alpha = 0.6F))
                    .fillMaxHeight()
            ) {
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .fillMaxWidth(),
                    value = organizationObjective,
                    onValueChange = { organizationObjective = it },
                    label = { Text("Organization Objective") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .fillMaxWidth(),
                    value = leadingIndicator,
                    onValueChange = { leadingIndicator = it },
                    label = { Text("Leading Indicator") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .fillMaxWidth(),
                    value = userOutcomes,
                    onValueChange = { userOutcomes = it },
                    label = { Text("User Outcomes") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                OutlinedTextField(
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .fillMaxWidth(),
                    value = modelProperties,
                    onValueChange = { modelProperties = it },
                    label = { Text("Model Properties") },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        containerColor = Color.White
                    )
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                        val meanObjData = MeanObjData(
                            organizationObjective,
                            leadingIndicator,
                            userOutcomes,
                            modelProperties
                        )
                        projectViewModel.saveMeanObjData(meanObjData)
                        saveMeanObjToFirestore(meanObjData, projekId) {
                            val intent = Intent(context, IntExp::class.java).apply {
                                putExtra("PROJEK_ID", projekId)
                            }
                            context.startActivity(intent)
                        }
                    },
                    modifier = Modifier
                        .width(135.dp)
                        .align(Alignment.CenterHorizontally)
                ) {
                    Text(text = "Save")
                }

            }
        }
    }
}

private fun saveMeanObjToFirestore(newEntry: MeanObjData, projekId: String, onSuccess: () -> Unit) {
    val db = FirebaseFirestore.getInstance()
    db.collection("dataProjek").document(projekId)
        .collection("meanObjData")
        .add(newEntry)
        .addOnSuccessListener {
            // Data berhasil disimpan
            Log.d("Firestore", "Data berhasil disimpan")
            onSuccess()
        }
        .addOnFailureListener { e ->
            // Tangani kesalahan
            Log.e("Firestore", "Gagal menyimpan data", e)
        }
}

@Preview(showBackground = true)
@Composable
fun MeanObjInputScreenPreview() {
    MeanObjInputScreen(projekId = "dummy_projek_id")
}
